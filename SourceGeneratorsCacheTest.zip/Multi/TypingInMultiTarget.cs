﻿namespace Multi
{
    public class TypingInMultiTarget
    {
        
    }
}

class NoError { }