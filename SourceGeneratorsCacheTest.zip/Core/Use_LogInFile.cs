﻿using LogInFile;

namespace Core
{
    public partial class Use_LogInFile
    {
        [LogInFile] private int t122 = 1;//comment
    }
}