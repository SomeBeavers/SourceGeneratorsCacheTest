﻿//using Big;
//namespace Core
//{
//    public partial class Use_Big
//    {
//        [Big]private string s = "";
//    }
//}