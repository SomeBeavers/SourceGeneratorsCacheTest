﻿using System;

namespace ReferenceMe_3
{
    public class Class12
    {
        public int t2121;
    }
}
