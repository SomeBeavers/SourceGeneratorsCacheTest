﻿using System;

namespace ReferencedByMe_1
{
    public class Class12
    {
        public int t;
        public int t23;
        public string s;
        public string s2;
        public string s3;
    }
}
